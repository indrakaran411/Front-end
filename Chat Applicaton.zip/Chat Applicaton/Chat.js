const socket = new WebSocket('ws://localhost:3000');

socket.addEventListener('open', function (event) {
  console.log('Connected to WebSocket server');
});

socket.addEventListener('message', function (event) {
  const messageBox = document.getElementById('chatBox');
  const message = document.createElement('div');
  message.textContent = event.data;
  messageBox.appendChild(message);
  messageBox.scrollTop = messageBox.scrollHeight;
});

function sendMessage() {
  const messageInput = document.getElementById('messageInput');
  const message = messageInput.value;
  socket.send(message);
  messageInput.value = '';
}
