let pendingTasks = [];
let completedTasks = [];

function addTask() {
    const taskInput = document.getElementById('taskInput');
    const task = taskInput.value.trim();

    if (task === "") return;

    const newTask = {
        id: Date.now(),
        description: task,
        dateAdded: new Date().toLocaleString()
    };

    pendingTasks.push(newTask);
    taskInput.value = '';
    renderTasks();
}

function renderTasks() {
    const pendingTasksUl = document.getElementById('pendingTasks');
    const completedTasksUl = document.getElementById('completedTasks');

    pendingTasksUl.innerHTML = '';
    completedTasksUl.innerHTML = '';

    pendingTasks.forEach(task => {
        const li = createTaskElement(task, false);
        pendingTasksUl.appendChild(li);
    });

    completedTasks.forEach(task => {
        const li = createTaskElement(task, true);
        completedTasksUl.appendChild(li);
    });
}

function createTaskElement(task, isCompleted) {
    const li = document.createElement('li');
    li.textContent = `${task.description} (Added: ${task.dateAdded})`;

    if (isCompleted) {
        li.classList.add('completed');
        li.innerHTML += ` (Completed: ${task.dateCompleted})`;
    }

    const buttonsDiv = document.createElement('div');
    buttonsDiv.classList.add('task-buttons');

    if (!isCompleted) {
        const completeButton = document.createElement('button');
        completeButton.textContent = 'Complete';
        completeButton.onclick = () => completeTask(task.id);
        buttonsDiv.appendChild(completeButton);
    }

    const editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.onclick = () => editTask(task.id);
    buttonsDiv.appendChild(editButton);

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.onclick = () => deleteTask(task.id, isCompleted);
    buttonsDiv.appendChild(deleteButton);

    li.appendChild(buttonsDiv);
    return li;
}

function completeTask(taskId) {
    const taskIndex = pendingTasks.findIndex(task => task.id === taskId);
    if (taskIndex > -1) {
        const [task] = pendingTasks.splice(taskIndex, 1);
        task.dateCompleted = new Date().toLocaleString();
        completedTasks.push(task);
        renderTasks();
    }
}

function editTask(taskId) {
    const task = pendingTasks.find(task => task.id === taskId) || completedTasks.find(task => task.id === taskId);
    if (task) {
        const newDescription = prompt('Edit task description:', task.description);
        if (newDescription !== null && newDescription.trim() !== "") {
            task.description = newDescription.trim();
            renderTasks();
        }
    }
}

function deleteTask(taskId, isCompleted) {
    if (isCompleted) {
        completedTasks = completedTasks.filter(task => task.id !== taskId);
    } else {
        pendingTasks = pendingTasks.filter(task => task.id !== taskId);
    }
    renderTasks();
}
