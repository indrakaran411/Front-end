const cards = ['A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'E', 'E', 'F', 'F', 'G', 'G', 'H', 'H'];
let flippedCards = [];
let matchedCards = [];

function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function createCard(card) {
  const div = document.createElement('div');
  div.textContent = card;
  div.classList.add('card');
  div.addEventListener('click', () => flipCard(div));
  return div;
}

function flipCard(card) {
  if (flippedCards.length < 2 && !matchedCards.includes(card)) {
    card.classList.add('flipped');
    flippedCards.push(card);

    if (flippedCards.length === 2) {
      setTimeout(checkMatch, 1000);
    }
  }
}

function checkMatch() {
  const [card1, card2] = flippedCards;
  if (card1.textContent === card2.textContent) {
    matchedCards.push(card1, card2);
    flippedCards = [];
    if (matchedCards.length === cards.length) {
      alert('Congratulations! You won the game!');
    }
  } else {
    flippedCards.forEach(card => card.classList.remove('flipped'));
    flippedCards = [];
  }
}

function resetGame() {
  matchedCards = [];
  flippedCards = [];
  gameBoard.innerHTML = '';
  initializeGame();
}

function initializeGame() {
  const shuffledCards = shuffle(cards);
  const gameBoard = document.getElementById('gameBoard');
  shuffledCards.forEach(card => {
    const div = createCard(card);
    gameBoard.appendChild(div);
  });
}

initializeGame();
