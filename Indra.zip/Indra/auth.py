import hashlib
from database import user_db

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def register_user(username, password):
    if username in user_db:
        return "Username already exists."
    user_db[username] = hash_password(password)
    return "User registered successfully."

def login_user(username, password):
    hashed_password = hash_password(password)
    if username in user_db and user_db[username] == hashed_password:
        return "Login successful."
    return "Invalid username or password."

def access_secure_page(username):
    if username in user_db:
        return "Access granted to the secure page."
    return "Access denied."
