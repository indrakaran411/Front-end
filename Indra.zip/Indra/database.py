# A dictionary to store user credentials (username: hashed_password)
user_db = {}
