from auth import register_user, login_user, access_secure_page

def main():
    while True:
        print("\n1. Register")
        print("2. Login")
        print("3. Access Secure Page")
        print("4. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            username = input("Enter username: ")
            password = input("Enter password: ")
            print(register_user(username, password))

        elif choice == '2':
            username = input("Enter username: ")
            password = input("Enter password: ")
            print(login_user(username, password))

        elif choice == '3':
            username = input("Enter username: ")
            print(access_secure_page(username))

        elif choice == '4':
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
