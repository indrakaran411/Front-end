async function searchRecipes() {
  const query = document.getElementById("query").value;
  const appId = 'YOUR_EDAMAM_APP_ID'; // Replace with your Edamam API app ID
  const appKey = 'YOUR_EDAMAM_APP_KEY'; // Replace with your Edamam API app key
  const apiUrl = `https://api.edamam.com/search?q=${query}&app_id=${appId}&app_key=${appKey}`;

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();
    displayRecipes(data.hits);
  } catch (error) {
    console.error('Error fetching recipes:', error);
  }
}

function displayRecipes(recipes) {
  const recipeList = document.getElementById("recipeList");
  recipeList.innerHTML = "";

  recipes.forEach(recipe => {
    const recipeDiv = document.createElement("div");
    recipeDiv.classList.add("recipe");

    const recipeTitle = document.createElement("h2");
    recipeTitle.textContent = recipe.recipe.label;

    const recipeIngredients = document.createElement("ul");
    recipe.recipe.ingredients.forEach(ingredient => {
      const ingredientItem = document.createElement("li");
      ingredientItem.textContent = ingredient.text;
      recipeIngredients.appendChild(ingredientItem);
    });

    const recipeLink = document.createElement("a");
    recipeLink.href = recipe.recipe.url;
    recipeLink.textContent = "View Recipe";

    recipeDiv.appendChild(recipeTitle);
    recipeDiv.appendChild(recipeIngredients);
    recipeDiv.appendChild(recipeLink);
    
    recipeList.appendChild(recipeDiv);
  });
}
